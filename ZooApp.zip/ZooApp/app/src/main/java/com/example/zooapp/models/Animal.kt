package com.example.zooapp.models

import com.example.zooapp.R

data class Animal (
    val id: Int,
    val name: String,
    val species: String,
    val imageRes: Int,
    val description: String,
    val curiosities: String,
    var isFavorite: Boolean = false
)



val animalList = listOf(
    Animal(
        id = 1,
        name = "Meu cat",
        species = "Canis lupus familiaris",
        imageRes = R.drawable.gato,
        description = "O cão é um dos animais mais antigos domesticados pelo homem.",
        curiosities = "Os cães têm um olfato cerca de 40 vezes mais potente que o dos humanos."
    ),
    Animal(
        id = 2,
        name = "bobi",
        species = "Felis catus",
        imageRes = R.drawable.bobi,
        description = "O cão doméstico é conhecido por sua agilidade e independência.",
        curiosities = "Cães passam cerca de 50% do dia dormindo."
    ),
    Animal(
        id = 3,
        name = "bobi",
        species = "Felis catus",
        imageRes = R.drawable.estevam,
        description = "O Estevam é conhecido por sua agilidade e independência.",
        curiosities = "ele passa cerca de 90% do dia dormindo."
    ),
)
