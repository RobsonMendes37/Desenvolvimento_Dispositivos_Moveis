package com.example.apppost.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFFC107), // Amarelo
    onPrimary = Color.Black, // Texto em cima do amarelo
    secondary = Color(0xFFFFD54F), // Amarelo claro
    onSecondary = Color.Black,
    surface = Color(0xFF121212), // Fundo escuro
    onSurface = Color.White,
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFFFFC107), // Amarelo
    onPrimary = Color.Black, // Texto em cima do amarelo
    secondary = Color(0xFFFFD54F), // Amarelo claro
    onSecondary = Color.Black,
    surface = Color.White, // Fundo claro
    onSurface = Color.Black,
)

@Composable
fun Apppost2Theme(
    darkTheme: Boolean = false, // Substitua por `isSystemInDarkTheme()` se quiser usar tema dinâmico
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}
