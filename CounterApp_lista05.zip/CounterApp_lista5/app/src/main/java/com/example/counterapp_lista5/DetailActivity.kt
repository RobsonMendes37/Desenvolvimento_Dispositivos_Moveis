package com.example.counterapp_lista5

import android.os.Bundle
import android.widget.TextView

override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_detail)

    // Recebe os dados enviados pela MainActivity
    val message = intent.getStringExtra("MESSAGE")
    val textView: TextView = findViewById(R.id.textView)
    textView.text = message // Exibe a mensagem recebida
}

