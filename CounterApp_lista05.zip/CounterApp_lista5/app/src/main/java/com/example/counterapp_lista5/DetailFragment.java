package com.example.counterapp_lista5;

import androidx.fragment.app.Fragment;

public class DetailFragment extends Fragment {
}
