package com.example.investidor.ui.theme

import androidx.compose.ui.graphics.Color

//val Green1 = Color(0xFF014804) // Verde Escuro
//val Green2 = Color(0xFF002C01) // Verde Vibrante
//val Green3 = Color(0xFF266528) // Verde Claro
//val Green4 = Color(0xFF336C33) // Verde Claro

val White = Color(0xFFFFFFFF) // Branco
val Black = Color(0xFF000000) // Preto para textos em fundo claro