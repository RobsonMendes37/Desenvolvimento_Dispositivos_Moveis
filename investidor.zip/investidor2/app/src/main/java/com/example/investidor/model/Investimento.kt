package com.example.investidor.model

data class Investimento(
    val nome: String = "",
    val valor: Int = 0
)
