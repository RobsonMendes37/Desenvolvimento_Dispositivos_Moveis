package com.example.profileapp

import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializando componentes
        val profileImage = findViewById<ImageView>(R.id.profileImage)
        val nameText = findViewById<TextView>(R.id.nameText)
        val descriptionText = findViewById<TextView>(R.id.descriptionText)
        val currentJobText = findViewById<TextView>(R.id.currentJobText)
        val experienceLayout = findViewById<LinearLayout>(R.id.experienceLayout)

        // Definindo informações de perfil
        nameText.text = "Menino Ronaldo"
        descriptionText.text = "Software Engeneir with 5 yers of experiencia."
        currentJobText.text = "Emprego Atual: Engenheira de Software na TechX"

        // Lista de experiências
        val experiencias = listOf(
            "•  Analista de Sistemas - Empresa A",
            "•  Desenvolvedora Júnior - Empresa B",
            "•  Estagiária - Empresa C",
            "•  Sou o melhor isso ja basta!"
        )

        // Adicionando experiências dinamicamente
        for (experiencia in experiencias) {
            val textView = TextView(this)
            textView.text = experiencia
            textView.textSize = 14f
            experienceLayout.addView(textView)
        }

        profileImage.setOnClickListener {
            Toast.makeText(this, "EU SOU O MELHOR!", Toast.LENGTH_SHORT).show()
        }

    }

}